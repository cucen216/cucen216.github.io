#include<iostream>

int main() {
    double val;

    std::cout << "Enter a number: ";
    std::cin >> val;
    std::cout << "This is your number: " << val << std::endl;

    return 0;

}